		
			


				</div><!-- inside-page -->
			</section><!-- content-wrapper -->
		</div><!-- content -->

	
		<!-- INCLUDE JS SCRIPTS -->

		<script src="Design/js/jquery.min.js"></script>
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<script src="Design/js/bootstrap.bundle.min.js"></script>
		<script src="Design/js/main.js"></script>

	</body>

	<!-- END BODY TAG -->

</html>

<!-- END HTML TAG -->